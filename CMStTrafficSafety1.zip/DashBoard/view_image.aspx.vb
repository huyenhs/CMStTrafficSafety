﻿
Partial Class DashBoard_view_image
    Inherits System.Web.UI.Page

End Class
