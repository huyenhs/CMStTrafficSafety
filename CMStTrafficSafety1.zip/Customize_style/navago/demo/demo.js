jQuery(document).ready(function() {
	function consoleWrite(message) {
		jQuery('#console').focus().append(message + '\n');
	}

	jQuery('#demo2').html(jQuery('#demo1').html());
	jQuery('#demo1 li').first().addClass('active');
	jQuery('#demo2 li').first().addClass('active');

	jQuery('#demo1, #demo2').find("li > a").click(function(e) {
		e.preventDefault();
		var isLink = jQuery(this).is("a");
		var href = isLink ? jQuery(this).attr('href') : '';

		if (isLink && href !== '#') {
			consoleWrite('Click my caret to open my submenu');
		} else if (isLink) {
			consoleWrite('Dummy link');
		}
	});

	consoleWrite('navgoco console waiting for input...');

	jQuery('pre > code').each(function() {
		var that = jQuery(this),
			type = that.attr('class'),
			source = that.data('source'),
			code = jQuery('#' + source + '-' + type).html();
		that.text(jQuery.trim(code));
	});

	jQuery(".tabs a").click(function(e) {
		e.preventDefault();
		jQuery(this).parent().siblings().removeClass('active').end().addClass('active');
		jQuery(this).parents('ul').next().children().hide().eq(jQuery(this).parent().index()).show();
	});

	jQuery(".panes").each(function() {
		jQuery(this).children().hide().eq(0).show();

	});
	hljs.tabReplace = '    ';
	hljs.initHighlightingOnLoad();
});


$(document).ready(function() {
    $('.nav').navgoco({
       
        accordion: true,
        openClass: 'open',
        save: true,
        slide: {
            duration: 400,
            easing: 'swing'
        }
    });
});